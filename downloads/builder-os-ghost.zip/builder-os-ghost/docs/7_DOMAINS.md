# 7 Domains

1. COMMAND - Control
2. BUILD - Create
3. CONNECT - Relate
4. PROTECT - Defend
5. GROW - Expand
6. LEARN - Understand
7. TRANSCEND - Become