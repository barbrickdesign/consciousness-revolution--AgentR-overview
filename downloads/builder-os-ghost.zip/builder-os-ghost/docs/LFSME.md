# LFSME Standard

Builder patterns are:
- Lighter
- Faster
- Stronger
- More Elegant
- Less Expensive

Ask: Is this LFSME?