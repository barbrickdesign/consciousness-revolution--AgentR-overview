# Manipulation Formula

M = (FE x CB x SR x CD x PE) x DC

FE=False Equivalence, CB=Cherry Benefits, SR=Strawman, CD=Commitment/Doubt, PE=Pressure/Emotion, DC=Deception Coefficient

M > 1 = Manipulation detected