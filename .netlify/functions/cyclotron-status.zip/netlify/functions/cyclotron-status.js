var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/cyclotron-status.mjs
var cyclotron_status_exports = {};
__export(cyclotron_status_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(cyclotron_status_exports);
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_url = require("url");
var import_meta = {};
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const indexPath = import_path.default.join(__dirname, "../../data/cyclotron_index.json");
    let cyclotronData = {
      total_atoms: 301,
      last_updated: (/* @__PURE__ */ new Date()).toISOString(),
      status: "operational",
      daemon_running: true,
      next_rake: "~3 minutes",
      growth_rate: "+0.4 atoms/min"
    };
    if (import_fs.default.existsSync(indexPath)) {
      const rawData = import_fs.default.readFileSync(indexPath, "utf8");
      const data = JSON.parse(rawData);
      cyclotronData = {
        total_atoms: data.total_atoms || cyclotronData.total_atoms,
        last_updated: data.last_updated || cyclotronData.last_updated,
        status: "operational",
        daemon_running: true,
        sessions_count: data.sessions ? data.sessions.length : 0
      };
    }
    const lastUpdate = new Date(cyclotronData.last_updated);
    const now = /* @__PURE__ */ new Date();
    const secondsAgo = Math.floor((now - lastUpdate) / 1e3);
    const nextRakeIn = 300 - secondsAgo % 300;
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ...cyclotronData,
        seconds_since_last_rake: secondsAgo,
        next_rake_in_seconds: nextRakeIn,
        is_running: secondsAgo < 600,
        // Consider running if raked in last 10 min
        timestamp: now.toISOString()
      })
    };
  } catch (error) {
    console.error("Cyclotron status error:", error);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        total_atoms: 301,
        last_updated: (/* @__PURE__ */ new Date()).toISOString(),
        status: "operational",
        daemon_running: true,
        error: "Using cached data",
        is_running: true
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
